web.py is a web framework for Python that is as simple as it is powerful.

Visit http://webpy.org/ for more information.

![build status](https://secure.travis-ci.org/webpy/webpy.png?branch=master)